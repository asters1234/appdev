from django.shortcuts import render

# Create your views here.
def about_view(request, *args, **kwargs):
    return render(request, 'about/about.html')

def contact_view(request,*args, **kwargs):
    return render(request, 'contact/contact.html')