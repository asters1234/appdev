from django.shortcuts import render, get_object_or_404, redirect

from .forms import ItemForm
from .models import Product
# Create your views here.

def item_list_view(request):
    queryset = Product.objects.all()
    context = {
        'object_list': queryset
    }
    return render(request, 'items/item_list.html', context)


def item_delete_view(request, id):# delete an item
    obj = get_object_or_404(Product, id=id)
    if request.method == 'POST':
        obj.delete()
        return redirect('../../')
    context = {
        'object': obj
    }
    return render(request, 'items/item_delete.html', context)


def item_create_view(request):# add an item
   form = ItemForm(request.POST or None)
   if form.is_valid():
       form.save()
       form = ItemForm()
   context = {
       'form': form,
   }
   return render(request, 'items/item_create.html', context)


def item_detail_view(request, id):
    obj = get_object_or_404(Product, id=id)
    context = {
        'object': obj,
    }
    return render(request, 'items/item_detail.html', context)


def item_update_view(request, id):
    obj = get_object_or_404(Product, id=id)
    form = ItemForm(request.POST or None,instance=obj)
    if form.is_valid():
        form.save()
    context = {
        'form': form
    }
    return render(request, 'items/item_create.html', context)