from django.urls import path

from .views import (
    item_update_view,
    item_detail_view,
    item_create_view,
    item_delete_view,
    item_list_view
)
app_name = 'item'
urlpatterns = [
    path('', item_list_view, name='item-list'),
    path('create/', item_create_view, name='item-create'),
    path('<int:id>/', item_detail_view, name='item-detail'),
    path('<int:id>/update/', item_update_view, name='item-update'),
    path('<int:id>/delete/', item_delete_view, name='item-delete'),
]