from django import forms

from .models import Product

class ItemForm(forms.ModelForm):
    title       = forms.CharField(label='', widget=forms.TextInput(attrs={'placeholder': 'Item Name'}))
    #email       = forms.EmailField()
    description = forms.CharField(
        required=False,
        widget=forms.Textarea(
            attrs={
                'placeholder': 'Item Description',
                'class': 'new-class name two',
                'rows': 20,
                'cols': 120
            }
        )
    )
    photo       = forms.ImageField()
    price       = forms.DecimalField()

    class Meta:
        model = Product
        fields = [
            'title',
            'description',
            'price',
            
        ]