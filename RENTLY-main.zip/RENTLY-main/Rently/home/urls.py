from django.urls import path

from .views import (
    nav_bar,
    register_request,
    login_request,
    home_view
)
app_name='home'
urlpatterns = [
    path('', home_view, name="home-home"),
    path('', nav_bar),
    path("register/", register_request, name="home-register"),
    path("login/", login_request, name="home-login")
]